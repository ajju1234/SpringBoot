package com.JPA.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.JPA.example.database.User;
@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

}
