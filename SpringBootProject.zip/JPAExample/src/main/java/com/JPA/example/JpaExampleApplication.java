package com.JPA.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.JPA.example.database.User;
import com.JPA.repository.UserRepository;

@SpringBootApplication
public class JpaExampleApplication {
    @Autowired
	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(JpaExampleApplication.class, args);
		
		UserRepository userRepository =context.getBean(UserRepository.class);
		User user=new User();
		user.setName("Ajit Trivedi");
		user.setCity("Mumbai");
		user.setStatus("Coder");
		
		User user1=userRepository.save(user);
		System.out.println(user1);
		
		
		
	}

}
